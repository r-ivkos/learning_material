var searchData=
[
  ['num_5fclusters_84',['num_clusters',['../classcjt__clusters.html#abf1bdef6cbcd45ac8795c22949ba8255',1,'cjt_clusters']]]
];
