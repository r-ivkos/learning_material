var searchData=
[
  ['gen_93',['gen',['../class_especie.html#ac35bb565f7346cd6317b3a8c849456d1',1,'Especie']]]
];
