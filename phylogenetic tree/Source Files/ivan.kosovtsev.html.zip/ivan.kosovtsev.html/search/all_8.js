var searchData=
[
  ['leer_5fespecies_38',['leer_especies',['../classcjt__especies.html#a4a15360291f2a857dfb78ef86bcef304',1,'cjt_especies']]],
  ['leer_5fk_39',['leer_k',['../class_especie.html#ab7eaacf952eda5b9ec47310180ee1b6c',1,'Especie']]]
];
