var searchData=
[
  ['kmero_80',['kmero',['../class_especie.html#af12be56a5ba229d00fcdbf1c3f84a764',1,'Especie']]]
];
