var searchData=
[
  ['asignar_5fcjt_0',['asignar_cjt',['../classcjt__especies.html#a3fbb752216d96878656303b73a52a21a',1,'cjt_especies']]],
  ['asignar_5fmatriz_1',['asignar_matriz',['../classcjt__especies.html#adfeb8ff70474d7bf0ebef3d8d74fa4fb',1,'cjt_especies']]]
];
