var searchData=
[
  ['id_94',['id',['../struct_nodo.html#ae23e512859fee47b4cc7dd9b99db97e3',1,'Nodo::id()'],['../class_especie.html#a91b94109fb8a456bba7199cdda36d588',1,'Especie::id()']]]
];
