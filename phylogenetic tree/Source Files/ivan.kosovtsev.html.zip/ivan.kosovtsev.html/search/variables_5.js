var searchData=
[
  ['k_95',['k',['../class_especie.html#a592c0ddeeebc786969f3040fbefea9df',1,'Especie']]],
  ['k_5fmero_96',['k_mero',['../class_especie.html#ad1a0594da11d61d0474ec036a6268742',1,'Especie']]]
];
