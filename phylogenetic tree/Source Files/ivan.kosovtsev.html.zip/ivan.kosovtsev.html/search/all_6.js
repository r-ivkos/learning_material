var searchData=
[
  ['id_29',['id',['../struct_nodo.html#ae23e512859fee47b4cc7dd9b99db97e3',1,'Nodo::id()'],['../class_especie.html#a91b94109fb8a456bba7199cdda36d588',1,'Especie::id()']]],
  ['imprimir_5farbol_30',['imprimir_arbol',['../classcjt__clusters.html#ac4925ee4d6ff9f9ca3a0f63b268c85d8',1,'cjt_clusters']]],
  ['imprimir_5fcluster_31',['imprimir_cluster',['../classcjt__clusters.html#a96c03b95281162ae25e29fde9636a4e9',1,'cjt_clusters::imprimir_cluster()'],['../class_cluster.html#a361c05611f6a030e65d66a30ff24b83f',1,'Cluster::imprimir_cluster()']]],
  ['imprimir_5fdistancias_32',['imprimir_distancias',['../classcjt__clusters.html#a8c1d081560d8219c28e580e7834a0bd4',1,'cjt_clusters::imprimir_distancias()'],['../classcjt__especies.html#af7cb17ee3b2a797703c78baf4de9de7c',1,'cjt_especies::imprimir_distancias()']]],
  ['imprimir_5fespecies_33',['imprimir_especies',['../classcjt__especies.html#a15729c608565b91d1f9ff38bc1c92c3d',1,'cjt_especies']]],
  ['inicializar_34',['inicializar',['../classcjt__clusters.html#a84cbc19e6c38cf0414f4c842c6cff2b5',1,'cjt_clusters']]]
];
