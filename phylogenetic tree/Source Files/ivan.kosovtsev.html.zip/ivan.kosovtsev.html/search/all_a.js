var searchData=
[
  ['nodo_41',['Nodo',['../struct_nodo.html',1,'Nodo'],['../class_cluster.html#a973261c201085c4df8d9d2dc8e372328',1,'Cluster::nodo()']]],
  ['num_5fclusters_42',['num_clusters',['../classcjt__clusters.html#abf1bdef6cbcd45ac8795c22949ba8255',1,'cjt_clusters']]]
];
