/** @mainpage
	
	Es una versi�n provisional de la documentaci�n de la pr�ctica de Ivan Kosovtsev.

	El programa principal se encuentra en el m�dulo main.cc.
	Atendiendo a los tipos de datos sugeridos en el enunciado, necesitaremos
	un m�dulo para representar el conjunto de especies y otro para representar
	el conjunto de cl�sters.	

*/

/** @file main.cc

    @brief El programa principal

	Estamos suponiendo que los datos le�dos siempre son correctos, ya que
	no incluimos comprobaciones al respecto. Para facilitar el uso de las funciones
	del conjunto de especies, el valor k >=0, que nos sera �til para calcular distancias
	entre especies, es una variable est�tica del dicho conjunto, y se lee desde la funci�n
	del mismo.

	<b>Comentario:</b> No se han definido las clases "especie" y "cluster", ya que son f�ciles de almacenar y gestionar con el <em>map</em> de la stl de c++

*/
#ifndef NO_DIAGRAM
#include <iostream>
#endif
#include "cjt_clusters.hh"
using namespace std;

int main() {

	Especie::leer_k();

	string opcion; //C�digo de operaci�n

	cjt_especies cesp; //El conjunto de especies con el que se trabajara
	cjt_clusters clust; //El conjunto de clusters con el que se trabajara

	while (cin >> opcion and opcion != "fin") { 

		if (opcion == "crea_especie") {
			string id, gen;
			cin >> id >> gen;
			cout << "# crea_especie " << id << " " << gen << endl;
			if (cesp.existe_especie(id)) cout << "ERROR: La especie " << id << " ya existe." << endl;
			else cesp.crear_especie(id, gen);
			cout << endl;
		}

		else if (opcion == "obtener_gen") {
			string id;
			cin >> id;
			cout << "# obtener_gen " << id << endl;
			if (not cesp.existe_especie(id)) cout << "ERROR: La especie " << id << " no existe." << endl << endl;
			else cout << cesp.consultar_gen(id) << endl << endl;
			
		}

		else if (opcion == "distancia") {
			string id1, id2;
			cin >> id1 >> id2;
			cout << "# distancia " << id1 << " " << id2 << endl;
			if (not cesp.existe_especie(id1) and cesp.existe_especie(id2)) 
				cout << "ERROR: La especie " << id1 << " no existe." << endl << endl;

			else if (cesp.existe_especie(id1) and not cesp.existe_especie(id2)) 
				cout << "ERROR: La especie " << id2 << " no existe." << endl << endl;

			else if (not cesp.existe_especie(id1) and not cesp.existe_especie(id2)) 
				cout << "ERROR: La especie " << id1 << " y la especie " << id2 << " no existen." << endl << endl;

			else cout << cesp.consultar_distancia(id1, id2) << endl << endl;
		}

		else if (opcion == "elimina_especie") {
			string id;
			cin >> id;
			cout << "# elimina_especie " << id << endl;
			if (not cesp.existe_especie(id)) cout << "ERROR: La especie " << id << " no existe." << endl;
			else cesp.eleminar_especie(id);
			cout << endl;
		}

		else if (opcion == "existe_especie") {
			string id;
			cin >> id;
			cout << "# existe_especie " << id << endl;
			if (cesp.existe_especie(id)) cout << "SI" << endl << endl;
			else cout << "NO" << endl << endl;
		}

		else if (opcion == "lee_cjt_especies") {
			cout << "# lee_cjt_especies" << endl;
			cesp.leer_especies();
			cout << endl;
		}

		else if (opcion == "imprime_cjt_especies") {
			cout << "# imprime_cjt_especies" << endl;
			cesp.imprimir_especies();
			cout << endl;
		}

		else if (opcion == "tabla_distancias") {
			cout << "# tabla_distancias" << endl;
			cesp.imprimir_distancias();
			cout << endl;
		}

		else if (opcion == "inicializa_clusters") {
			cout << "# inicializa_clusters" << endl;
			clust.inicializar(cesp);
			clust.imprimir_distancias();
			cout << endl; 
		}

		else if (opcion == "ejecuta_paso_wpgma") {
			cout << "# ejecuta_paso_wpgma" << endl;
			if (clust.num_clusters() <= 1) cout << "ERROR: num_clusters <= 1" << endl << endl;
			else {
				clust.paso_wpgma();
				clust.imprimir_distancias();
				cout << endl;
			}
		}

		else if (opcion == "imprime_cluster") {
			string id;
			cin >> id;
			cout << "# imprime_cluster " << id << endl;
			if (not clust.existe_cluster(id)) cout << "ERROR: El cluster " << id << " no existe."; 
			else clust.imprimir_cluster(id);
			cout << endl << endl;
		}

		else if (opcion == "imprime_arbol_filogenetico") {
			cout << "# imprime_arbol_filogenetico" << endl;
			clust.formar_arbol(cesp);
			if (clust.num_clusters() == 0) cout << "ERROR: El conjunto de clusters es vacio.";
			else clust.imprimir_arbol();
			cout << endl << endl;

		}
	}
}